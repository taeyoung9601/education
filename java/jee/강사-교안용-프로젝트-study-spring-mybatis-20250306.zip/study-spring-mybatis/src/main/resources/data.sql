-- MySQL v8.x

INSERT INTO city(name, state, country) VALUES
('Alabama', 'AL', 'US'),
('Alaska', 'AK', 'US'),
('Arizona', 'AZ', 'US'),
('Arkansas', 'AR', 'US'),
('California', 'CA', 'US'),
('Colorado', 'CO', 'US'),
('Connecticut', 'CT', 'US'),
('Delaware', 'DE', 'US'),
('Florida', 'FL', 'US'),
('Georgia', 'GA', 'US'),
('Hawaii', 'HI', 'US'),
('Idaho', 'ID', 'US'),
('Illinois', 'IL', 'US'),
('Indiana', 'IN', 'US'),
('Iowa', 'IA', 'US'),
('Kansas', 'KS', 'US'),
('Kentucky', 'KY', 'US'),
('Louisiana', 'LA', 'US'),
('Maine', 'ME', 'US'),
('Maryland', 'MD', 'US'),
('Massachusetts', 'MA', 'US'),
('Michigan', 'MI', 'US'),
('Minnesota', 'MN', 'US'),
('Mississippi', 'MS', 'US'),
('Missouri', 'MO', 'US'),
('Montana', 'MT', 'US'),
('Nebraska', 'NE', 'US'),
('Nevada', 'NV', 'US'),
('New Hampshire', 'NH', 'US'),
('New Jersey', 'NJ', 'US'),
('New Mexico', 'NM', 'US'),
('New York', 'NY', 'US'),
('North Carolina', 'NC', 'US'),
('North Dakota', 'ND', 'US'),
('Ohio', 'OH', 'US'),
('Oklahoma', 'OK', 'US'),
('Oregon', 'OR', 'US'),
('Pennsylvania', 'PA', 'US'),
('Rhode Island', 'RI', 'US'),
('South Carolina', 'SC', 'US'),
('South Dakota', 'SD', 'US'),
('Tennessee', 'TN', 'US'),
('Texas', 'TX', 'US'),
('Utah', 'UT', 'US'),
('Vermont', 'VT', 'US'),
('Virginia', 'VA', 'US'),
('Washington', 'WA', 'US'),
('West Virginia', 'WV', 'US'),
('Wisconsin', 'WI', 'US'),
('Wyoming', 'WY', 'US');

COMMIT;

-- --------------

INSERT INTO hotel (city, name, address, zip) VALUES 
((SELECT id FROM city WHERE state = 'AL'), 'Alabama Hotel', '123 Alabama St', '35203'),
((SELECT id FROM city WHERE state = 'AK'), 'Alaska Hotel', '456 Alaska Rd', '99501'),
((SELECT id FROM city WHERE state = 'AZ'), 'Arizona Hotel', '789 Arizona Ave', '85001'),
((SELECT id FROM city WHERE state = 'AR'), 'Arkansas Hotel', '101 Arkansas Blvd', '72201'),
((SELECT id FROM city WHERE state = 'CA'), 'California Hotel', '202 California Dr', '90001'),
((SELECT id FROM city WHERE state = 'CO'), 'Colorado Hotel', '303 Colorado St', '80202'),
((SELECT id FROM city WHERE state = 'CT'), 'Connecticut Hotel', '404 Connecticut Ln', '06103'),
((SELECT id FROM city WHERE state = 'DE'), 'Delaware Hotel', '505 Delaware Ave', '19901'),
((SELECT id FROM city WHERE state = 'FL'), 'Florida Hotel', '606 Florida Blvd', '33101'),
((SELECT id FROM city WHERE state = 'GA'), 'Georgia Hotel', '707 Georgia St', '30303'),
((SELECT id FROM city WHERE state = 'HI'), 'Hawaii Hotel', '808 Hawaii Dr', '96801'),
((SELECT id FROM city WHERE state = 'ID'), 'Idaho Hotel', '909 Idaho Ave', '83701'),
((SELECT id FROM city WHERE state = 'IL'), 'Illinois Hotel', '1010 Illinois Rd', '60601'),
((SELECT id FROM city WHERE state = 'IN'), 'Indiana Hotel', '1111 Indiana St', '46204'),
((SELECT id FROM city WHERE state = 'IA'), 'Iowa Hotel', '1212 Iowa Dr', '50309'),
((SELECT id FROM city WHERE state = 'KS'), 'Kansas Hotel', '1313 Kansas Ave', '66101'),
((SELECT id FROM city WHERE state = 'KY'), 'Kentucky Hotel', '1414 Kentucky Blvd', '40202'),
((SELECT id FROM city WHERE state = 'LA'), 'Louisiana Hotel', '1515 Louisiana St', '70112'),
((SELECT id FROM city WHERE state = 'ME'), 'Maine Hotel', '1616 Maine Rd', '04101'),
((SELECT id FROM city WHERE state = 'MD'), 'Maryland Hotel', '1717 Maryland Ave', '21201'),
((SELECT id FROM city WHERE state = 'MA'), 'Massachusetts Hotel', '1818 Massachusetts St', '02108'),
((SELECT id FROM city WHERE state = 'MI'), 'Michigan Hotel', '1919 Michigan Dr', '48226'),
((SELECT id FROM city WHERE state = 'MN'), 'Minnesota Hotel', '2020 Minnesota Ave', '55101'),
((SELECT id FROM city WHERE state = 'MS'), 'Mississippi Hotel', '2121 Mississippi Blvd', '39201'),
((SELECT id FROM city WHERE state = 'MO'), 'Missouri Hotel', '2222 Missouri St', '63103'),
((SELECT id FROM city WHERE state = 'MT'), 'Montana Hotel', '2323 Montana Ave', '59101'),
((SELECT id FROM city WHERE state = 'NE'), 'Nebraska Hotel', '2424 Nebraska Rd', '68102'),
((SELECT id FROM city WHERE state = 'NV'), 'Nevada Hotel', '2525 Nevada St', '89501'),
((SELECT id FROM city WHERE state = 'NH'), 'New Hampshire Hotel', '2626 New Hampshire Ave', '03301'),
((SELECT id FROM city WHERE state = 'NJ'), 'New Jersey Hotel', '2727 New Jersey St', '07302'),
((SELECT id FROM city WHERE state = 'NM'), 'New Mexico Hotel', '2828 New Mexico Blvd', '87501'),
((SELECT id FROM city WHERE state = 'NY'), 'New York Hotel', '2929 New York Rd', '10001'),
((SELECT id FROM city WHERE state = 'NC'), 'North Carolina Hotel', '3030 North Carolina Ave', '27601'),
((SELECT id FROM city WHERE state = 'ND'), 'North Dakota Hotel', '3131 North Dakota St', '58102'),
((SELECT id FROM city WHERE state = 'OH'), 'Ohio Hotel', '3232 Ohio Blvd', '44114'),
((SELECT id FROM city WHERE state = 'OK'), 'Oklahoma Hotel', '3333 Oklahoma St', '73102'),
((SELECT id FROM city WHERE state = 'OR'), 'Oregon Hotel', '3434 Oregon Ave', '97201'),
((SELECT id FROM city WHERE state = 'PA'), 'Pennsylvania Hotel', '3535 Pennsylvania Blvd', '19103'),
((SELECT id FROM city WHERE state = 'RI'), 'Rhode Island Hotel', '3636 Rhode Island Rd', '02903'),
((SELECT id FROM city WHERE state = 'SC'), 'South Carolina Hotel', '3737 South Carolina St', '29201'),
((SELECT id FROM city WHERE state = 'SD'), 'South Dakota Hotel', '3838 South Dakota Ave', '57104'),
((SELECT id FROM city WHERE state = 'TN'), 'Tennessee Hotel', '3939 Tennessee Blvd', '37203'),
((SELECT id FROM city WHERE state = 'TX'), 'Texas Hotel', '4040 Texas St', '75201'),
((SELECT id FROM city WHERE state = 'UT'), 'Utah Hotel', '4141 Utah Ave', '84101'),
((SELECT id FROM city WHERE state = 'VT'), 'Vermont Hotel', '4242 Vermont Rd', '05602'),
((SELECT id FROM city WHERE state = 'VA'), 'Virginia Hotel', '4343 Virginia Blvd', '23219'),
((SELECT id FROM city WHERE state = 'WA'), 'Washington Hotel', '4444 Washington St', '98001'),
((SELECT id FROM city WHERE state = 'WV'), 'West Virginia Hotel', '4545 West Virginia Rd', '25301'),
((SELECT id FROM city WHERE state = 'WI'), 'Wisconsin Hotel', '4646 Wisconsin Ave', '53202'),
((SELECT id FROM city WHERE state = 'WY'), 'Wyoming Hotel', '4747 Wyoming St', '82901');

COMMIT;

SELECT * FROM city;
SELECT * FROM hotel;


-- H2 Database

INSERT INTO city(name, state, country) VALUES
('Alabama', 'AL', 'US'),
('Alaska', 'AK', 'US'),
('Arizona', 'AZ', 'US'),
('Arkansas', 'AR', 'US'),
('California', 'CA', 'US'),
('Colorado', 'CO', 'US'),
('Connecticut', 'CT', 'US'),
('Delaware', 'DE', 'US'),
('Florida', 'FL', 'US'),
('Georgia', 'GA', 'US'),
('Hawaii', 'HI', 'US'),
('Idaho', 'ID', 'US'),
('Illinois', 'IL', 'US'),
('Indiana', 'IN', 'US'),
('Iowa', 'IA', 'US'),
('Kansas', 'KS', 'US'),
('Kentucky', 'KY', 'US'),
('Louisiana', 'LA', 'US'),
('Maine', 'ME', 'US'),
('Maryland', 'MD', 'US'),
('Massachusetts', 'MA', 'US'),
('Michigan', 'MI', 'US'),
('Minnesota', 'MN', 'US'),
('Mississippi', 'MS', 'US'),
('Missouri', 'MO', 'US'),
('Montana', 'MT', 'US'),
('Nebraska', 'NE', 'US'),
('Nevada', 'NV', 'US'),
('New Hampshire', 'NH', 'US'),
('New Jersey', 'NJ', 'US'),
('New Mexico', 'NM', 'US'),
('New York', 'NY', 'US'),
('North Carolina', 'NC', 'US'),
('North Dakota', 'ND', 'US'),
('Ohio', 'OH', 'US'),
('Oklahoma', 'OK', 'US'),
('Oregon', 'OR', 'US'),
('Pennsylvania', 'PA', 'US'),
('Rhode Island', 'RI', 'US'),
('South Carolina', 'SC', 'US'),
('South Dakota', 'SD', 'US'),
('Tennessee', 'TN', 'US'),
('Texas', 'TX', 'US'),
('Utah', 'UT', 'US'),
('Vermont', 'VT', 'US'),
('Virginia', 'VA', 'US'),
('Washington', 'WA', 'US'),
('West Virginia', 'WV', 'US'),
('Wisconsin', 'WI', 'US'),
('Wyoming', 'WY', 'US');

COMMIT;

-- -----------------------

INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'AL'), 'Alabama Hotel', '123 Alabama St', '35203');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'AK'), 'Alaska Hotel', '456 Alaska Rd', '99501');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'AZ'), 'Arizona Hotel', '789 Arizona Ave', '85001');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'AR'), 'Arkansas Hotel', '101 Arkansas Blvd', '72201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'CA'), 'California Hotel', '202 California Dr', '90001');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'CO'), 'Colorado Hotel', '303 Colorado St', '80202');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'CT'), 'Connecticut Hotel', '404 Connecticut Ln', '06103');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'DE'), 'Delaware Hotel', '505 Delaware Ave', '19901');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'FL'), 'Florida Hotel', '606 Florida Blvd', '33101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'GA'), 'Georgia Hotel', '707 Georgia St', '30303');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'HI'), 'Hawaii Hotel', '808 Hawaii Dr', '96801');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'ID'), 'Idaho Hotel', '909 Idaho Ave', '83701');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'IL'), 'Illinois Hotel', '1010 Illinois Rd', '60601');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'IN'), 'Indiana Hotel', '1111 Indiana St', '46204');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'IA'), 'Iowa Hotel', '1212 Iowa Dr', '50309');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'KS'), 'Kansas Hotel', '1313 Kansas Ave', '66101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'KY'), 'Kentucky Hotel', '1414 Kentucky Blvd', '40202');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'LA'), 'Louisiana Hotel', '1515 Louisiana St', '70112');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'ME'), 'Maine Hotel', '1616 Maine Rd', '04101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MD'), 'Maryland Hotel', '1717 Maryland Ave', '21201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MA'), 'Massachusetts Hotel', '1818 Massachusetts St', '02108');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MI'), 'Michigan Hotel', '1919 Michigan Dr', '48226');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MN'), 'Minnesota Hotel', '2020 Minnesota Ave', '55101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MS'), 'Mississippi Hotel', '2121 Mississippi Blvd', '39201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MO'), 'Missouri Hotel', '2222 Missouri St', '63103');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MT'), 'Montana Hotel', '2323 Montana Ave', '59101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NE'), 'Nebraska Hotel', '2424 Nebraska Rd', '68102');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NV'), 'Nevada Hotel', '2525 Nevada St', '89501');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NH'), 'New Hampshire Hotel', '2626 New Hampshire Ave', '03301');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NJ'), 'New Jersey Hotel', '2727 New Jersey St', '07302');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NM'), 'New Mexico Hotel', '2828 New Mexico Blvd', '87501');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NY'), 'New York Hotel', '2929 New York Rd', '10001');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NC'), 'North Carolina Hotel', '3030 North Carolina Ave', '27601');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'ND'), 'North Dakota Hotel', '3131 North Dakota St', '58102');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'OH'), 'Ohio Hotel', '3232 Ohio Blvd', '44114');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'OK'), 'Oklahoma Hotel', '3333 Oklahoma St', '73102');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'OR'), 'Oregon Hotel', '3434 Oregon Ave', '97201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'PA'), 'Pennsylvania Hotel', '3535 Pennsylvania Blvd', '19103');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'RI'), 'Rhode Island Hotel', '3636 Rhode Island Rd', '02903');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'SC'), 'South Carolina Hotel', '3737 South Carolina St', '29201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'SD'), 'South Dakota Hotel', '3838 South Dakota Ave', '57104');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'TN'), 'Tennessee Hotel', '3939 Tennessee Blvd', '37203');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'TX'), 'Texas Hotel', '4040 Texas St', '75201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'UT'), 'Utah Hotel', '4141 Utah Ave', '84101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'VT'), 'Vermont Hotel', '4242 Vermont Rd', '05602');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'VA'), 'Virginia Hotel', '4343 Virginia Blvd', '23219');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'WA'), 'Washington Hotel', '4444 Washington St', '98001');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'WV'), 'West Virginia Hotel', '4545 West Virginia Rd', '25301');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'WI'), 'Wisconsin Hotel', '4646 Wisconsin Ave', '53202');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'WY'), 'Wyoming Hotel', '4747 Wyoming St', '82901');

COMMIT;

SELECT * FROM city;
SELECT * FROM hotel;


-- ORACLE19CR3

INSERT INTO city (name, state, country) VALUES ('Alabama', 'AL', 'US');
INSERT INTO city (name, state, country) VALUES ('Alaska', 'AK', 'US');
INSERT INTO city (name, state, country) VALUES ('Arizona', 'AZ', 'US');
INSERT INTO city (name, state, country) VALUES ('Arkansas', 'AR', 'US');
INSERT INTO city (name, state, country) VALUES ('California', 'CA', 'US');
INSERT INTO city (name, state, country) VALUES ('Colorado', 'CO', 'US');
INSERT INTO city (name, state, country) VALUES ('Connecticut', 'CT', 'US');
INSERT INTO city (name, state, country) VALUES ('Delaware', 'DE', 'US');
INSERT INTO city (name, state, country) VALUES ('Florida', 'FL', 'US');
INSERT INTO city (name, state, country) VALUES ('Georgia', 'GA', 'US');
INSERT INTO city (name, state, country) VALUES ('Hawaii', 'HI', 'US');
INSERT INTO city (name, state, country) VALUES ('Idaho', 'ID', 'US');
INSERT INTO city (name, state, country) VALUES ('Illinois', 'IL', 'US');
INSERT INTO city (name, state, country) VALUES ('Indiana', 'IN', 'US');
INSERT INTO city (name, state, country) VALUES ('Iowa', 'IA', 'US');
INSERT INTO city (name, state, country) VALUES ('Kansas', 'KS', 'US');
INSERT INTO city (name, state, country) VALUES ('Kentucky', 'KY', 'US');
INSERT INTO city (name, state, country) VALUES ('Louisiana', 'LA', 'US');
INSERT INTO city (name, state, country) VALUES ('Maine', 'ME', 'US');
INSERT INTO city (name, state, country) VALUES ('Maryland', 'MD', 'US');
INSERT INTO city (name, state, country) VALUES ('Massachusetts', 'MA', 'US');
INSERT INTO city (name, state, country) VALUES ('Michigan', 'MI', 'US');
INSERT INTO city (name, state, country) VALUES ('Minnesota', 'MN', 'US');
INSERT INTO city (name, state, country) VALUES ('Mississippi', 'MS', 'US');
INSERT INTO city (name, state, country) VALUES ('Missouri', 'MO', 'US');
INSERT INTO city (name, state, country) VALUES ('Montana', 'MT', 'US');
INSERT INTO city (name, state, country) VALUES ('Nebraska', 'NE', 'US');
INSERT INTO city (name, state, country) VALUES ('Nevada', 'NV', 'US');
INSERT INTO city (name, state, country) VALUES ('New Hampshire', 'NH', 'US');
INSERT INTO city (name, state, country) VALUES ('New Jersey', 'NJ', 'US');
INSERT INTO city (name, state, country) VALUES ('New Mexico', 'NM', 'US');
INSERT INTO city (name, state, country) VALUES ('New York', 'NY', 'US');
INSERT INTO city (name, state, country) VALUES ('North Carolina', 'NC', 'US');
INSERT INTO city (name, state, country) VALUES ('North Dakota', 'ND', 'US');
INSERT INTO city (name, state, country) VALUES ('Ohio', 'OH', 'US');
INSERT INTO city (name, state, country) VALUES ('Oklahoma', 'OK', 'US');
INSERT INTO city (name, state, country) VALUES ('Oregon', 'OR', 'US');
INSERT INTO city (name, state, country) VALUES ('Pennsylvania', 'PA', 'US');
INSERT INTO city (name, state, country) VALUES ('Rhode Island', 'RI', 'US');
INSERT INTO city (name, state, country) VALUES ('South Carolina', 'SC', 'US');
INSERT INTO city (name, state, country) VALUES ('South Dakota', 'SD', 'US');
INSERT INTO city (name, state, country) VALUES ('Tennessee', 'TN', 'US');
INSERT INTO city (name, state, country) VALUES ('Texas', 'TX', 'US');
INSERT INTO city (name, state, country) VALUES ('Utah', 'UT', 'US');
INSERT INTO city (name, state, country) VALUES ('Vermont', 'VT', 'US');
INSERT INTO city (name, state, country) VALUES ('Virginia', 'VA', 'US');
INSERT INTO city (name, state, country) VALUES ('Washington', 'WA', 'US');
INSERT INTO city (name, state, country) VALUES ('West Virginia', 'WV', 'US');
INSERT INTO city (name, state, country) VALUES ('Wisconsin', 'WI', 'US');
INSERT INTO city (name, state, country) VALUES ('Wyoming', 'WY', 'US');

COMMIT;

-- ------------------------------
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'AL'), 'Alabama Hotel', '123 Alabama St', '35203');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'AK'), 'Alaska Hotel', '456 Alaska Rd', '99501');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'AZ'), 'Arizona Hotel', '789 Arizona Ave', '85001');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'AR'), 'Arkansas Hotel', '101 Arkansas Blvd', '72201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'CA'), 'California Hotel', '202 California Dr', '90001');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'CO'), 'Colorado Hotel', '303 Colorado St', '80202');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'CT'), 'Connecticut Hotel', '404 Connecticut Ln', '06103');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'DE'), 'Delaware Hotel', '505 Delaware Ave', '19901');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'FL'), 'Florida Hotel', '606 Florida Blvd', '33101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'GA'), 'Georgia Hotel', '707 Georgia St', '30303');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'HI'), 'Hawaii Hotel', '808 Hawaii Dr', '96801');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'ID'), 'Idaho Hotel', '909 Idaho Ave', '83701');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'IL'), 'Illinois Hotel', '1010 Illinois Rd', '60601');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'IN'), 'Indiana Hotel', '1111 Indiana St', '46204');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'IA'), 'Iowa Hotel', '1212 Iowa Dr', '50309');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'KS'), 'Kansas Hotel', '1313 Kansas Ave', '66101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'KY'), 'Kentucky Hotel', '1414 Kentucky Blvd', '40202');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'LA'), 'Louisiana Hotel', '1515 Louisiana St', '70112');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'ME'), 'Maine Hotel', '1616 Maine Rd', '04101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MD'), 'Maryland Hotel', '1717 Maryland Ave', '21201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MA'), 'Massachusetts Hotel', '1818 Massachusetts St', '02108');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MI'), 'Michigan Hotel', '1919 Michigan Dr', '48226');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MN'), 'Minnesota Hotel', '2020 Minnesota Ave', '55101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MS'), 'Mississippi Hotel', '2121 Mississippi Blvd', '39201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MO'), 'Missouri Hotel', '2222 Missouri St', '63103');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'MT'), 'Montana Hotel', '2323 Montana Ave', '59101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NE'), 'Nebraska Hotel', '2424 Nebraska Rd', '68102');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NV'), 'Nevada Hotel', '2525 Nevada St', '89501');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NH'), 'New Hampshire Hotel', '2626 New Hampshire Ave', '03301');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NJ'), 'New Jersey Hotel', '2727 New Jersey St', '07302');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NM'), 'New Mexico Hotel', '2828 New Mexico Blvd', '87501');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NY'), 'New York Hotel', '2929 New York Rd', '10001');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'NC'), 'North Carolina Hotel', '3030 North Carolina Ave', '27601');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'ND'), 'North Dakota Hotel', '3131 North Dakota St', '58102');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'OH'), 'Ohio Hotel', '3232 Ohio Blvd', '44114');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'OK'), 'Oklahoma Hotel', '3333 Oklahoma St', '73102');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'OR'), 'Oregon Hotel', '3434 Oregon Ave', '97201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'PA'), 'Pennsylvania Hotel', '3535 Pennsylvania Blvd', '19103');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'RI'), 'Rhode Island Hotel', '3636 Rhode Island Rd', '02903');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'SC'), 'South Carolina Hotel', '3737 South Carolina St', '29201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'SD'), 'South Dakota Hotel', '3838 South Dakota Ave', '57104');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'TN'), 'Tennessee Hotel', '3939 Tennessee Blvd', '37203');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'TX'), 'Texas Hotel', '4040 Texas St', '75201');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'UT'), 'Utah Hotel', '4141 Utah Ave', '84101');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'VT'), 'Vermont Hotel', '4242 Vermont Rd', '05602');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'VA'), 'Virginia Hotel', '4343 Virginia Blvd', '23219');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'WA'), 'Washington Hotel', '4444 Washington St', '98001');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'WV'), 'West Virginia Hotel', '4545 West Virginia Rd', '25301');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'WI'), 'Wisconsin Hotel', '4646 Wisconsin Ave', '53202');
INSERT INTO hotel (city, name, address, zip) VALUES ((SELECT id FROM city WHERE state = 'WY'), 'Wyoming Hotel', '4747 Wyoming St', '82901');

COMMIT;

SELECT * FROM city;
SELECT * FROM hotel;




