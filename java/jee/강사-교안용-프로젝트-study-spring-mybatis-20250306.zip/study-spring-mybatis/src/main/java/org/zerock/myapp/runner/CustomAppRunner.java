package org.zerock.myapp.runner;

import java.util.Objects;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;


@Log4j2
@NoArgsConstructor

@Component  // * Required *
public class CustomAppRunner implements ApplicationRunner {
    @Autowired private SqlSessionFactory sqlSessionFactory;
    @Autowired private SqlSession sqlSession;
    @Autowired private SqlSessionTemplate sqlSessionTemplate;


    @Override
    public void run(ApplicationArguments args) {
        log.trace("run({}) invoked.", args);

        Objects.requireNonNull(this.sqlSessionFactory);
        log.info("\t+1. this.sqlSessionFactory: {}", this.sqlSessionFactory);

        Objects.requireNonNull(this.sqlSession);
        log.info("\t+2. this.sqlSession: {}", this.sqlSession);

        Objects.requireNonNull(this.sqlSession);
        log.info("\t+3. this.sqlSessionTemplate: {}", this.sqlSessionTemplate);
    } // run

} // end class
