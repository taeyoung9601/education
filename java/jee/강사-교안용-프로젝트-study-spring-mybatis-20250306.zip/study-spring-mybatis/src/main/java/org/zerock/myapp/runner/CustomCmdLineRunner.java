package org.zerock.myapp.runner;

import java.util.Arrays;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.zerock.myapp.mybatis.mapper.CityMapper;
import org.zerock.myapp.mybatis.mapper.DateTimeMapper;
import org.zerock.myapp.mybatis.mapper.HotelMapper;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;


@Log4j2
@NoArgsConstructor

@Component  // * Required *
public class CustomCmdLineRunner implements CommandLineRunner {
	@Autowired private CityMapper cityMapper;
	@Autowired private DateTimeMapper dateTimeMapper;
	@Autowired private HotelMapper hotelMapper;


    @Override
    public void run(String... args) {
        log.trace("run({}) invoked.", Arrays.toString(args));

        Objects.requireNonNull(this.cityMapper);
        log.info("\t+1. this.cityMapper: {}, type: {}", this.cityMapper, this.cityMapper.getClass().getName());

        Objects.requireNonNull(this.dateTimeMapper);
        log.info("\t+2. this.dateTimeMapper: {}, type: {}", this.dateTimeMapper, this.dateTimeMapper.getClass().getName());

        Objects.requireNonNull(this.hotelMapper);
        log.info("\t+3. this.hotelMapper: {}, type: {}", this.hotelMapper, this.hotelMapper.getClass().getName());
    } // run

} // end class
