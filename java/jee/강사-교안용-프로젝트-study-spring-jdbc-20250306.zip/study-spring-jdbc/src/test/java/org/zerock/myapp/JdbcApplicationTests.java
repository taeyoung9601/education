package org.zerock.myapp;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.Timeout;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.annotation.Commit;

import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j2;


@Log4j2
@NoArgsConstructor

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

/**
 * ----------------------
 * @Commit
 * ----------------------
    This a test annotation that is used to indicate that a test-managed transaction should be committed after the test method has completed. 
	Consult the class-level Javadoc for org.springframework.test.context.transaction.TransactionalTestExecutionListener for an explanation of test-managed transactions. 

	(1) When declared as a class-level annotation, 
		  @Commit defines the default commit semantics for all test methods within the test class hierarchy or nested class hierarchy.
	 
	 (2) When declared as a method-level annotation, 
		  @Commit defines commit semantics for the specific test method, potentially overriding class-level default commit or rollback semantics. 
 */
@Commit

/**
 * ----------------------
 * @Rollback
 * ----------------------
 	This is a test annotation that is used to indicate whether a test-managed transaction should be rolled back after the test method has completed. 
	Consult the class-level Javadoc for org.springframework.test.context.transaction.TransactionalTestExecutionListener for an explanation of test-managed transactions. 
	
	(1) When declared as a *class-level annotation, 
		  @Rollback defines the default rollback semantics for all test methods within the test class hierarchy or nested class hierarchy.
	
	(2) When declared as a *method-level annotation, 
		  @Rollback defines rollback semantics for the specific test method, potentially overriding class-level default commit or rollback semantics. 

	(3) @Commit can be used as direct replacement for @Rollback(false). (***)
	
	Warning: Declaring @Commit and @Rollback on the same test method or on the same test class is unsupported and may lead to unpredictable results. (***)	
	*/
//@Rollback

@SpringBootTest
class JdbcApplicationTests {
	@Autowired private ApplicationContext ctx;


	
	@BeforeAll
	void beforeAll() {
		log.trace("beforeAll() invoked.");
		
		Objects.requireNonNull(this.ctx);
		log.info("\t+ this.ctx: {}", this.ctx);
		
		assertNotNull(null);
	} // beforeAll
	
	
//    @Disabled
    @Order(1)
	@Test
//	@RepeatedTest(1)
    @DisplayName("testContextLoads")
    @Timeout(value=1L, unit=TimeUnit.SECONDS)
	void testContextLoads() {
        log.trace("testContextLoads() invoked.");

        String[] beanNames = this.ctx.getBeanDefinitionNames();
        List<String> list = Arrays.<String>asList(beanNames);
        list.forEach(log::info);
	} // testContextLoads

} // end class
